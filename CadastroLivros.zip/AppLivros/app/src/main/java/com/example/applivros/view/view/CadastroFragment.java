package com.example.applivros.view.view;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.applivros.R;
import com.example.applivros.databinding.FragmentCadastroBinding;
import com.example.applivros.view.modelDominio.Livro;
import com.example.applivros.view.viewModel.InfoViewModel;

import java.text.NumberFormat;
import java.util.Locale;

public class CadastroFragment extends Fragment {

    InfoViewModel infoViewModel;
    FragmentCadastroBinding binding;

    NumberFormat nf = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
      binding = FragmentCadastroBinding.inflate(inflater, container, false);
      return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        infoViewModel = new ViewModelProvider(getActivity()).get(InfoViewModel.class);

        binding.Bvoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Navigation.findNavController(view).navigate(R.id.action_cadastroFragment_homeFragment);
            }
        });

        binding.BcadastroCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!binding.ETcadastroTitulo.getText().toString().equals("")) {
                    if (!binding.ETcadastroAnoLancamento.getText().toString().equals("")) {
                        if (!binding.ETcadastroPreco.getText().toString().equals("")) {
                            if (binding.RBtecnico.isChecked() || binding.RBficcao.isChecked() || binding.RBromance.isChecked()) {

                                String titulo = binding.ETcadastroTitulo.getText().toString();
                                int anoLancamento = Integer.parseInt(binding.ETcadastroAnoLancamento.getText().toString());
                                Double preco = Double.parseDouble(binding.ETcadastroPreco.getText().toString());
                                int genero;

                                if (binding.RBtecnico.isChecked()) {
                                    genero = 1;
                                } else  if (binding.RBficcao.isChecked()) {
                                    genero = 2;
                                } else {
                                    genero = 3;
                                }

                                Livro objLivro = new Livro(titulo, anoLancamento, preco, genero);
                                infoViewModel.getListaLivros().add(objLivro);
                                Toast.makeText(getContext(), "Livro cadastrado com sucesso", Toast.LENGTH_SHORT).show();
                                clear();

                            } else {
                                Toast.makeText(getContext(), "Informe o gênero", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            binding.ETcadastroPreco.setError("Informe o preço");
                            binding.ETcadastroPreco.requestFocus();
                        }
                    } else {
                        binding.ETcadastroAnoLancamento.setError("Informe o ano de lançamento");
                        binding.ETcadastroAnoLancamento.requestFocus();
                    }
                } else {
                    binding.ETcadastroTitulo.setError("Informe o título");
                    binding.ETcadastroTitulo.requestFocus();
                }
            }
        });

        binding.BcadastroCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clear();
            }
        });
    }

    public void clear() {
        binding.ETcadastroTitulo.setText("");
        binding.ETcadastroAnoLancamento.setText("");
        binding.ETcadastroPreco.setText("");
        binding.RGcategoria.clearCheck();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}