package com.example.applivros.view.modelDominio;

public class Livro {

    private String titulo;
    private int anoLancamento;
    private Double valor;
    private  int genero;

    public Livro(String titulo, int anoLancamento, Double valor, int genero) {
        this.titulo = titulo;
        this.anoLancamento = anoLancamento;
        this.valor = valor;
        this.genero = genero;
    }

    public String getGeneroLiteral() {
        String retorno = "";

        if (this.genero == 1) {
            retorno = "Técnico";
        } else if (this.genero == 2) {
            retorno = "Ficção";
        } else {
            retorno = "Romance";
        }
        return retorno;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getAnoLancamento() {
        return anoLancamento;
    }

    public void setAnoLancamento(int anoLancamento) {
        this.anoLancamento = anoLancamento;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public int getGenero() {
        return genero;
    }

    public void setGenero(int genero) {
        this.genero = genero;
    }
}
