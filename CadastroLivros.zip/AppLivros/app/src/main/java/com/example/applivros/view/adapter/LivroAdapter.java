package com.example.applivros.view.adapter;

import androidx.recyclerview.widget.RecyclerView;
import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.applivros.databinding.ItemListRowBinding;
import com.example.applivros.view.modelDominio.Livro;

import java.util.List;

public class LivroAdapter extends RecyclerView.Adapter<LivroAdapter.MyViewHolder> {
    private List<Livro> listaLivros;
    private LivroOnClickListener livroOnClickListener;

    public LivroAdapter(List<Livro> listaLivros, LivroOnClickListener livroOnClickListener) {
        this.listaLivros = listaLivros;
        this.livroOnClickListener = livroOnClickListener;
    }

    @Override
    public LivroAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        ItemListRowBinding itemListRowBinding = ItemListRowBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new MyViewHolder(itemListRowBinding);
    }

    @Override
    public void onBindViewHolder(final LivroAdapter.MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        Livro meuLivro = listaLivros.get(position);
        holder.itemListRowBinding.TVviewTitulo.setText(meuLivro.getTitulo());
        holder.itemListRowBinding.TVviewGenero.setText(meuLivro.getGeneroLiteral());

        if (livroOnClickListener != null) {
            holder.itemListRowBinding.getRoot().setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    livroOnClickListener.onClickLivro(holder.itemView, position, meuLivro);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return listaLivros.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public  ItemListRowBinding itemListRowBinding;
        public MyViewHolder(ItemListRowBinding itemListRowBinding) {
            super(itemListRowBinding.getRoot());
            this.itemListRowBinding = itemListRowBinding;
        }
    }

    public interface LivroOnClickListener {
        public void onClickLivro(View view, int position, Livro livro);
    }
}
