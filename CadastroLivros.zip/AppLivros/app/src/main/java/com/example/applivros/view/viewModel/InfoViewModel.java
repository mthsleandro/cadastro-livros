package com.example.applivros.view.viewModel;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.applivros.view.modelDominio.Livro;

import java.util.ArrayList;

public class InfoViewModel extends ViewModel {
    private MutableLiveData<ArrayList<Livro>> mListaLivros;

    public ArrayList<Livro> getListaLivros() {
        if (mListaLivros == null) {
            mListaLivros = new MutableLiveData<>();
            ArrayList<Livro> listaLivros = new ArrayList<>();
            mListaLivros.setValue(listaLivros);
        }
        return mListaLivros.getValue();
    }
}
