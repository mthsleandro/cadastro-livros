package com.example.applivros.view.view;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.applivros.R;
import com.example.applivros.databinding.FragmentLoginBinding;

public class LoginFragment extends Fragment {

    FragmentLoginBinding binding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentLoginBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.Blogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (!binding.ETusuario.getText().toString().equals("")) {
                    if (!binding.ETsenha.getText().toString().equals("")) {

                        String usuario = binding.ETusuario.getText().toString();
                        String senha = binding.ETsenha.getText().toString();

                        if (usuario.equals("lorenzi") && senha.equals("1234")){

                        Navigation.findNavController(view).navigate(R.id.action_loginFragment_homeFragment);

                        } else {
                            Toast.makeText(getContext(), "Usuário ou senha inválidos", Toast.LENGTH_SHORT).show();
                        }

                    } else {
                        binding.ETsenha.setError("Informe a senha");
                        binding.ETsenha.requestFocus();
                    }
                } else {
                    binding.ETusuario.setError("Informe o usuário");
                    binding.ETusuario.requestFocus();
                }
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}