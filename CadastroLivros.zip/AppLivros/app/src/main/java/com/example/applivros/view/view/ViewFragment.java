package com.example.applivros.view.view;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.applivros.R;
import com.example.applivros.databinding.FragmentViewBinding;
import com.example.applivros.view.adapter.LivroAdapter;
import com.example.applivros.view.modelDominio.Livro;
import com.example.applivros.view.viewModel.InfoViewModel;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;

public class ViewFragment extends Fragment {

    FragmentViewBinding binding;
    InfoViewModel infoViewModel;

    LivroAdapter livroAdapter;

    NumberFormat nf = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentViewBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        infoViewModel = new ViewModelProvider(getActivity()).get(InfoViewModel.class);

        if (infoViewModel.getListaLivros() != null) {
            refresh();
        }

        binding.Bvoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Navigation.findNavController(view).navigate(R.id.action_viewFragment_homeFragment);
            }
        });
    }

    public void refresh() {
        livroAdapter = new LivroAdapter(infoViewModel.getListaLivros(), onItemClick);
        binding.RVviewLivros.setLayoutManager(new LinearLayoutManager(getContext()));
        binding.RVviewLivros.setItemAnimator(new DefaultItemAnimator());
        binding.RVviewLivros.setAdapter(livroAdapter);
    }

    LivroAdapter.LivroOnClickListener onItemClick = new LivroAdapter.LivroOnClickListener() {
        @Override
        public void onClickLivro(View view, int position, Livro livro) {
            Toast.makeText(getContext(), "Título: " + livro.getTitulo() + "\nGênero: " + livro.getGeneroLiteral() + "\nLançamento: " + livro.getAnoLancamento() + "\nPreço: " + nf.format(livro.getValor()), Toast.LENGTH_SHORT).show();
        }
    };

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}